<?php
	session_start();
	if ( !isset($_SESSION['user_id']) ) {
		require_once ('includes/login_functions.inc.php');
		
		$url = absolute_url('login.php');
		
		header("location: $url");
		exit();
	}
	$user = $_SESSION['user_id'];
	$name = $_SESSION['first_name'];
	$page_title = 'Calculate my spends';
	$page_link_one = '<li class="active"><a href="index.php">Update spending</a></li>';
	$page_link_two = '<li><a href="query.php">View spending</a></li>';
	
	include ('includes/header.html');

?>
        <h2>Hello <?php echo $name ?></h2>
        <form class="form-horizontal" id="spends" name="spends" method="post" action="form-handler.php">
        
            <fieldset>
                <legend>Enter item</legend>  
                <div class="control-group">  
                    <label for="spend-title" class="control-label" >Title</label>
                    <div class="controls">
                    	<input name="spend-title" placeholder="Spend name" type="text" />
                    </div>
				</div>
                <div class="control-group">
	                <label for="spend-amount" class="control-label" >Amount</label>
                    <div class="controls"> 
                    	<input name="spend-amount" placeholder="0.00" type="number" required max="9999" min="0" step="0.01" />
                    </div>
                </div>
                <div class="control-group">
                    <label for="spend-category" class="control-label" >Category </label>
                    <div class="controls">
                        <select name="spend-category" required="required" >
                        	<option value="" selected="selected" disabled>Choose a category...</option>
                            <?php
                                date_default_timezone_set('GMT');
                                function make_category_pulldown() {
                                    $categorys = array ('Food', 'Drink', 'Smokes', 'Travel', 'Rent', 'Bills', 'Eating out', 'Entertainment', 'Clothes', 'Miscellaneous');	
                                    foreach ($categorys as $key => $value) {
                                        echo "<option value = '$value'>$value</option>";	
                                    }
                                }
                                
                                make_category_pulldown();
                            
                            ?>
                        </select>
					</div>
				</div>
                <div class="control-group">
                	<label for="spend-description" class="control-label" >Description</label>
                    <div class="controls">
	                    <textarea name="spend-description" placeholder="Description (optional)" rows="3" cols="40"></textarea>
                    </div>
                </div>
                    
            </fieldset>
            <div class="control-group">
                <div class="controls">
		            <button type="submit" class="btn btn-primary">Update spends</button>
                </div>
            </div>
            <input type="hidden" name="submitted" value="TRUE" />
            <input type="hidden" name="start" value="<?php echo time(); ?>" />
            <div class="control-group">
                <div class="controls">
                    <p><a href="query.php" class="btn">View spends</a></p>
                </div>
            </div>
        </form>

        <p><a href="logout.php" class="btn" style="float:right">Logout</a></p>
        <div class="clear-fix"></div>
        
            <?php
				/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				// load in include file according to local/live environment
				if ( !@include('includes/mysqli_connect.php') ) {
					require_once ('mysqli_connect.php');
				} else {
                	require_once ('includes/mysqli_connect.php');
				}
				
				// Check when the user gets paid
				$queryPay = "SELECT payday, wage FROM users WHERE user_id = " . $_SESSION['user_id'] . "";
				
				$rp = mysqli_query($dbc, $queryPay);
				$rowPay = mysqli_fetch_array($rp, MYSQLI_ASSOC);
				
				/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				// Check the dates function. Takes the day and runs it through checkdate
				// If checkdate fails initiate a backwards loop until we get a valid day
				function validateDay($day) {

					$month = date("m", strtotime("last month") );
					$year = date("Y", strtotime("last month") );

					if ( checkdate($month, $day, $year) ) {
						// Date passes check, return as string
						return $day;
						
					} elseif ( !checkdate($month, $day, $year) ) {
						// Date is invlaid, reduce by one until it passes validation
						while ( !checkdate($month, $day, $year) ) {
							$day--;
						} //END WHILE
						return $day;
					} // END ELSEIF

				} //END VALIDATEDAY
				
				/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				//Check if the last date of pay was in this month or last month
				//Do this by determining if current day is less than date of pay, equal to (got paid today) or greater then (got paid this month)
				function lastPay($day) {
					$currentDay = date('d');
					
					if ( $currentDay < $day ) {
						// Got paid last month
						$fromDateMonth = date('Y-m-d', strtotime('last day of last month'));
						return $fromDateMonth;
						
					} elseif ( $currentDay == $day ) {
						// Got paid today
						$fromDateMonth = date('Y-m-d');
						return $fromDateMonth;
						
					} elseif ( $currentDay > $day ) {
						// Got paid this month
						$fromDateMonth = date('Y-m-' . $day);
						return $fromDateMonth;
						
					}
				} //END LASTPAY
				
				/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				if ($rp) {
					$wage = $rowPay['wage'];
					// Check payday result and format the query to see how much spent since last pay
					if ( $rowPay['payday'] == 'last' ) { // User gets paid on the last day of every month
						$day = date('d',  strtotime('last day of last month') );
						//Check when they last got paid
						$fromDateMonth = lastPay($day);
						
					} if ( is_numeric($rowPay['payday']) ) { // User gets paid on the XX of the month
						// Check this payday is valid, ie. in range of previous month
						$day = $rowPay['payday'];
						$day = validateDay($day);
						$fromDateMonth = lastPay($day);
						
					}
				} else {
					echo 'AN ERROR OCCURRED';
				}

				if ( $fromDateMonth == date('Y-m-d') ) {
					echo '<h2>You got paid today!</h2>';
				} else {
					echo '<h2>You last got paid on: ' . $fromDateMonth . '</h2>';
				}

                $query = "SELECT time, SUM(amount) AS 'sum' FROM monthly_spends_" . $user . " WHERE time > '$fromDateMonth';";
				$query2 = "SELECT SUM(amount) AS 'sum2' FROM monthly_spends_" . $user . "";
				
                $r = mysqli_query($dbc, $query);
                $row = mysqli_fetch_array($r, MYSQLI_ASSOC);
				
				$r2 = mysqli_query($dbc, $query2);
				$row2 = mysqli_fetch_array($r2, MYSQLI_ASSOC);
				
				
				if ($r2) {
					
					echo '<h2><small>Current spend of ALL TIME!: </small>£';
					if ( is_null( $row2['sum2'] ) ){
						echo '0.00';
					} else {
						echo $row2['sum2'] . '</h2>';
					}
					
				} else {
					echo '<h2>Y\'all done fucked-up!</h2>';	
				}
				
                if ($r) {
					$totalSpend = $row['sum'];
								 
					function wage_spent($wage, $totalSpend) {
						$percent = (int) ( ($totalSpend / $wage) * 100);
						return $percent;
					}
					
					echo '<h2><small>Current spend from last last pay day: </small>£';
					if ( is_null($totalSpend) ) {
						echo '0.00'; 
					} else {
                    	echo $totalSpend;
						echo '<small>: or ' . wage_spent($wage, $totalSpend) . '% of your wages since you got paid.</small>';
					}
                } else {
                    echo 'AN ERROR OCCURRED';
                }
    			
				echo '</h2>';
				include ('includes/footer.html');

            ?>
 