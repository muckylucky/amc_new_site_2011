<?php

	$page_title = 'Login';
	
	include('includes/header.html');
	
    if ( !empty($errors) ) {
        echo '<h1>Error!</h1>
              <p class="error">The following error(s) occurred:<br />';
        foreach ($errors as $msg) {
            echo " - $msg<br />\n";	
        }
    }
	
?>


<h1>Login</h1>

<form action="login.php" method="post" class="form-horizontal" autocomplete="on">
	<fieldset>
      <div class="control-group">  
              <label for="email"  class="control-label">Email address: </label>
              <div class="controls">
                  <input type="email" name="email" size="20" maxlength="80" />
              </div>
      </div>
      <div class="control-group">  
              <label for="password" class="control-label">Password: </label>
              <div class="controls">
                  <input type="password" name="password" size="20" maxlength="20" />
              </div>
      </div>
      <div class="control-group">  
      		<div class="controls">
            		<label class="checkbox">
						<input type="checkbox" name="remember" value="yes"> Remember me </label>
                        <br />
                  <input type="submit" name="submit" value="login" class="btn btn-primary" />
                  <span> Or </span>
                  <a href="register.php" class="btn" style="margin-left:30px">Register</a>
			</div>
      </div>
    <input type="hidden" name="submitted" value="TRUE" />
    
	</fieldset>
</form>

<?php
	include('includes/footer.html');
?>