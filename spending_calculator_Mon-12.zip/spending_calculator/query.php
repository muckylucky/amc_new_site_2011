<?php
	session_start();
	if ( !isset($_SESSION['user_id']) ) {
		require_once ('includes/login_functions.inc.php');
		
		$url = absolute_url('login.php');
		
		header("location: $url");
		exit();
	}
	$user = $_SESSION['user_id'];
	$name = $_SESSION['first_name'];
	$page_title = 'View my spending';
	$page_link_one = '<li><a href="index.php">Update spending</a></li>';
	$page_link_two = '<li class="active"><a href="query.php">View spending</a></li>';
	
	include ('includes/header.html');

?>

        <form class="form-horizontal" id="spends" name="spends" method="post" action="query.php">
        
            <fieldset>
                <legend>Query spending</legend>  
   
                <div class="control-group">
                    <label for="spend-category" class="control-label" >Category </label>
                    <div class="controls">
                        <select name="spend-category" required="required" >
                        	<option value="" selected="selected" disabled>Choose a category...</option>
                            <?php
                                function make_category_pulldown() {
                                    $categorys = array ('Food', 'Drink', 'Smokes', 'Travel', 'Rent', 'Bills', 'Eating out', 'Entertainment', 'Clothes', 'Miscellaneous');	
                                    foreach ($categorys as $key => $value) {
                                        echo "<option value = '$value'>$value</option>";	
                                    }
                                }
                                
                                make_category_pulldown();
                            
                            ?>
                        </select>
					</div>
				</div>
  
                    
            </fieldset>
            <div class="control-group">
                <div class="controls">
		            <button type="submit" class="btn btn-primary">View spending</button>
                </div>
            </div>
            <input type="hidden" name="submitted" value="TRUE" />
            <div class="control-group">
                <div class="controls">
                    <p><a href="index.php" class="btn">Update spends</a></p>
                </div>
            </div>
        </form>


        <p><a href="logout.php" class="btn" style="float:right">Logout</a></p>
        <div class="clear-fix"></div>
        
            <?php
				/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				// load in include file according to local/live environment
				if ( !@include('includes/mysqli_connect.php') ) {
					require_once ('mysqli_connect.php');
				} else {
                	require_once ('includes/mysqli_connect.php');
				}
				
				// Check when the user gets paid
				$queryPay = "SELECT payday FROM users WHERE user_id = " . $_SESSION['user_id'] . "";
				
				$rp = mysqli_query($dbc, $queryPay);
				$rowPay = mysqli_fetch_array($rp, MYSQLI_ASSOC);
				
				/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				// Check the dates function. Takes the day and runs it through checkdate
				// If checkdate fails initiate a backwards loop until we get a valid day
				function validateDay($day) {

					$month = date("m", strtotime("last month") );
					$year = date("Y", strtotime("last month") );

					if ( checkdate($month, $day, $year) ) {
						// Date passes check, return as string
						return $day;
						
					} elseif ( !checkdate($month, $day, $year) ) {
						// Date is invlaid, reduce by one until it passes validation
						while ( !checkdate($month, $day, $year) ) {
							$day--;
						} //END WHILE
						return $day;
					} // END ELSEIF

				} //END VALIDATEDAY
				
				/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				//Check if the last date of pay was in this month or last month
				//Do this by determining if current day is less than date of pay, equal to (got paid today) or greater then (got paid this month)
				function lastPay($day) {
					$currentDay = date('d');
					
					if ( $currentDay < $day ) {
						// Got paid last month
						$fromDateMonth = date('Y-m-d', strtotime('last day of last month'));
						return $fromDateMonth;
						
					} elseif ( $currentDay == $day ) {
						// Got paid today
						$fromDateMonth = date('Y-m-d');
						return $fromDateMonth;
						
					} elseif ( $currentDay > $day ) {
						// Got paid this month
						$fromDateMonth = date('Y-m-' . $day);
						return $fromDateMonth;
						
					}
				} //END LASTPAY
				
				/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
				if ($rp) {
					// Check payday result and format the query to see how much spent since last pay
					if ( $rowPay['payday'] == 'last' ) { // User gets paid on the last day of every month
						$day = date('d',  strtotime('last day of last month') );
						
						//Check when they last got paid
						$fromDateMonth = lastPay($day);
						
					} if ( is_numeric($rowPay['payday']) ) { // User gets paid on the XX of the month
						// Check this payday is valid, ie. in range of previous month
						$day = $rowPay['payday'];
						$day = validateDay($day);
						$fromDateMonth = lastPay($day);
						
					}
				} else {
					echo 'AN ERROR OCCURRED';
				}
				
				if ( isset($_POST['spend-category']) ) {
					$cat = $_POST['spend-category'];
					$query = "SELECT time, SUM(amount) AS 'sum' FROM monthly_spends_" . $user . " WHERE category = '$cat' AND time > '$fromDateMonth';";
					
					
				} else {
					'<h2>An error has happened</h2>';
					'<p class="error">No category selected.</p>';
				}

                //$query = "SELECT time, SUM(amount) AS 'sum' FROM monthly_spends_" . $user . " WHERE time > '$fromDateMonth';";
				
                $r = mysqli_query($dbc, $query);
                $row = mysqli_fetch_array($r, MYSQLI_ASSOC);				
				
                if ($r) {
					echo '<h2><small>Current spend from last last pay day: </small>£';
					if ( is_null($row['sum']) ) {
						echo '0.00'; 
					} else {
                    	echo $row['sum'];
					}
                } else {
                    echo 'AN ERROR OCCURRED';
                }
    			
				echo '</h2>';
				include ('includes/footer.html');

            ?>
