<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>Photography by Andrew McCluckie</title>
<link rel="stylesheet" type="text/css" href="main.css" />
<script type="text/javascript" src="jquery.js"></script>
<script>
	$(document).ready(function(){
		/* Thiscode will work in conjunction with the PHP to submit the requests to itself. Thumbnails and large/main images must have matching filenames
		and must be stored in adjacent directories - make sure the directories match the code
		*/
		
		/* AJAX function to load in the relevant 'set' of images. Passes request to the PHP function in this same page and returns the relevant html */
		var setLoader = function(selection){ 
			var $default = selection || 'lot_1'; // Sets default image directory if no selection has been made i.e on initial load
			var $target = $('#photo_viewer'); // Target element to load content into
			var $content = ''; // Initialise variable to store returned html
			/* Make the AJAX call */
	 		$.ajax({ 
				type : "GET",  
                url : 'photography.php?set=' + $default, // URL references self but with PHP query variable
                dataType : "html",  
                success : function( data ) {  // Return the PHP query result
					$content = $(data).find('#photo_viewer').children(); // Grab the relevent content from the returned html
					$($target).empty().append($content).hide().fadeIn(); // Clear the target content, append the query results and insert into DOM
				}
			});
	
		}; // END LOADER FUNC
		
		/* Function to handle the 'set' navigation */
		var linkHandler = function(){
			$('#phot_links').find('a').click(function(e){
				e.preventDefault(); // Disable anchor default behaviour
				$selected = $(this).attr('href'); // Grab the set selection from the links' href property
				setLoader($selected); // Run the AJAX load function and pass the selection to it
			}); // END CLICK FUNC
		};
		
		linkHandler();
		
		/* Function for the behaviour of the image thumbnails to load the main image */
		/* Use live as after the initial load all elements are generated dynamically and do not exist in DOM at time of js script execution */
		$('#photo_thumbs_wrapper').find('a').live('click', function(e){
							var $imgUrl = ''; // used to store the image path
							//var $imgName = ''; // currently not used
							e.preventDefault();
							$imgUrl = $(this).find('img').attr('src').split('/'); // Split image path so we can grab the filename portion
							/* Swap-out the /thumb/ fragment for the /large/ directory to get main image and pass to main image loader below*/									
							image_loader($imgUrl[0] + '/large/' + $imgUrl[2]); 
		});
		
		/* Function to handle loading of main image based on thumbnail selection */
		var image_loader = function(name){
			$('#main_photo').fadeOut(200, function(){ // Ditch the current main image
				$(this).attr('src', name).load(function() { // load the new image with callback func to check image dimensions
        			pic_real_width = this.naturalWidth;   // Note: $(this).width() will not
        			pic_real_height = this.naturalHeight; // work for in memory images.
					$(this).animate({width: pic_real_width, height: pic_real_height}, 200); // Adjust the new image size
    			}).fadeIn(200);						  
											  
			});
		} //END IMAGE LOADER
		
	

		
	});
</script>
</head>

<body>
	<div id="wrapper">
    	
        <ul id="phot_links">
    		<li><a href="lot_1">Lot one</a> | </li>
    		<li><a href="lot_2">Lot two</a> | </li>
    		<li><a href="lot_3">Lot three</a></li>
        </ul>
        
    	<div id="photo_viewer">
        	
            

				<?php
                	$set = "lot_1"; // Value set as default for intial load
					$defaultMainImage = "001.jpg"; // See above ^
					$defaultMainImagePath = $set . "/large/001.jpg"; // Get full image url
                    $imgArray = array();
					$defaultImageSize = getimagesize($defaultMainImagePath); // Get dimensions of main image - saves on browser 'painting' time
					
					/* Check to see if set variable has been defined - it won't have on initial load */
					if (isset($_GET['set']) ) {
						$set = $_GET['set'];
						$defaultMainImagePath = $set . "/large/001.jpg"; // Construct full image path
						$defaultImageSize = getimagesize($defaultMainImagePath); // Get image dimensions
					} 
					
					echo '<h1 id="selected_set">' . $set . '</h1>';	
					
					echo '<img id="main_photo" src="' . $defaultMainImagePath . '" width="' . $defaultImageSize[0] . '" height="' . $defaultImageSize[1] . '" alt="Main image" />'; // Display main image
					echo '<div id="photo_thumbs_wrapper">'; // Open the thumbnail wrapper.
					
                    /* Open aspecified directory, and proceed to read its contents to generate the thumbnails
					   Will grab all images of jpg or gif type
					*/
                    foreach(glob($set . "/thumb/{*.jpg,*.gif}", GLOB_BRACE) as $image)
                    {
                        $split = explode('/', $image); // Split image path to get filename
                        $img = $split[2];
                        array_push($imgArray, $set . 'thumb/' . $image); // Store images in an array in case needed for later development/refinement
                        $size = getimagesize($set . '/thumb/' . $img); // Get each thumbnails size. Should all be same but you never know
                        echo '<a href="' . $set . 'large/' . $img . '" target="blank"><img src="' . $set . '/thumb/' . $img . '" class="photo_thumbs" alt="image thumbnail" width="' . $size[0] . '" height="' . $size[1] . '"/></a>'; //Output the html for thumbnail
                    }
                	echo '</div><!--END THUMBS WRAPPER-->';

                ?>
		</div><!--END PHOT VIEWER-->
	</div><!--END WRAPPER -->
</body>
</html>